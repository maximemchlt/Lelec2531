// LELEC2531 - MAC accelerator: proposed baseline (not a course-provided solution).
// 32-bit input word: {A[15:0], B[15:0]}, signed two's complement.
// 8-bit CFG0: bit 0 = accumulate (1) / replace (0)
//             bit 1 = clear accumulator on CFG0 write (write-one pulse)
//             bits 7:2 = reserved (read back as zero)
// 8-bit CFG1: bits 4:0 = arithmetic shift applied to A*B (0..31)
//             bits 7:5 = reserved (read back as zero)
// Writing the input automatically starts one operation.
// The input and its settings are registered at the write clock edge;
// the 32-bit output register updates at the next rising edge.
// After pipeline fill, it accepts at most one input each clock.
// On overflow, 32-bit accumulator wraps modulo 2^32 (no saturation).
// Priority: a CFG0 write with clear=1 cancels the pending output update
// at that same rising edge. Do not clear while an operation is in flight.

module mac_core (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        wr_input,
    input  logic        wr_cfg0,
    input  logic        wr_cfg1,
    input  logic [31:0] write_data,
    output logic [31:0] input_reg_q,
    output logic [7:0]  cfg0_reg_q,
    output logic [7:0]  cfg1_reg_q,
    output logic [31:0] result_reg_q,
    output logic        result_valid
);

    logic        pending_q;
    logic        pending_accumulate_q;
    logic [4:0]  pending_shift_q;

    logic signed [31:0] a_sign_extended;
    logic signed [31:0] b_sign_extended;
    logic signed [31:0] product;
    logic signed [31:0] scaled_product;
    logic signed [31:0] accumulator_base;

    assign a_sign_extended = {{16{input_reg_q[31]}}, input_reg_q[31:16]};
    assign b_sign_extended = {{16{input_reg_q[15]}}, input_reg_q[15:0]};
    assign product          = a_sign_extended * b_sign_extended;
    assign scaled_product   = product >>> pending_shift_q;
    assign accumulator_base = pending_accumulate_q ? $signed(result_reg_q) : 32'sd0;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            input_reg_q         <= 32'd0;
            cfg0_reg_q          <= 8'h01; // accumulate enabled by default
            cfg1_reg_q          <= 8'h00; // no shift by default
            result_reg_q        <= 32'd0;
            result_valid        <= 1'b0;
            pending_q           <= 1'b0;
            pending_accumulate_q<= 1'b0;
            pending_shift_q     <= 5'd0;
        end else begin
            // Decode one write strobe per clock cycle in normal use.
            if (wr_cfg0)
                cfg0_reg_q <= {7'b0, write_data[0]};
            if (wr_cfg1)
                cfg1_reg_q <= {3'b0, write_data[4:0]};

            // Stage 1: capture a packed operand pair and its configuration.
            pending_q <= wr_input;
            if (wr_input) begin
                input_reg_q          <= write_data;
                pending_accumulate_q<= cfg0_reg_q[0];
                pending_shift_q     <= cfg1_reg_q[4:0];
            end

            // Stage 2: registered output, with explicit clear priority.
            result_valid <= 1'b0;
            if (wr_cfg0 && write_data[1]) begin
                result_reg_q <= 32'd0;
            end else if (pending_q) begin
                result_reg_q <= accumulator_base + scaled_product;
                result_valid <= 1'b1;
            end
        end
    end
endmodule
