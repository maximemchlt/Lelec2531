`timescale 1ns/1ps
module tb_mac_core;
    logic clk = 1'b0;
    always #5 clk = ~clk;

    logic rst_n = 1'b0;
    logic wr_input = 1'b0;
    logic wr_cfg0 = 1'b0;
    logic wr_cfg1 = 1'b0;
    logic [31:0] write_data = 32'd0;
    logic [31:0] input_reg_q;
    logic [7:0] cfg0_reg_q, cfg1_reg_q;
    logic [31:0] result_reg_q;
    logic result_valid;

    mac_core dut (
        .clk(clk), .rst_n(rst_n),
        .wr_input(wr_input), .wr_cfg0(wr_cfg0), .wr_cfg1(wr_cfg1),
        .write_data(write_data),
        .input_reg_q(input_reg_q),
        .cfg0_reg_q(cfg0_reg_q),
        .cfg1_reg_q(cfg1_reg_q),
        .result_reg_q(result_reg_q),
        .result_valid(result_valid)
    );

    // Hold a write strobe around one full rising edge.
    // reg_id: 0=input, 1=cfg0, 2=cfg1
    task automatic write_reg(input integer reg_id, input logic [31:0] data);
        @(negedge clk);
        write_data = data;
        wr_input = (reg_id == 0);
        wr_cfg0  = (reg_id == 1);
        wr_cfg1  = (reg_id == 2);
        @(negedge clk);
        wr_input = 1'b0;
        wr_cfg0  = 1'b0;
        wr_cfg1  = 1'b0;
        write_data = 32'd0;
    endtask

    // The result is computed on the rising edge following the input write.
    task automatic expect_result(input logic [31:0] expected, input string label);
        @(posedge clk);
        #1;
        if (result_reg_q !== expected) begin
            $error("%s: expected 0x%08h (%0d), got 0x%08h (%0d)",
                   label, expected, $signed(expected),
                   result_reg_q, $signed(result_reg_q));
            $fatal(1, "Test FAILED");
        end
        $display("PASS %-24s result=%0d (0x%08h)",
                 label, $signed(result_reg_q), result_reg_q);
    endtask

    initial begin
        repeat (3) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;

        write_reg(1, 32'h0000_0001); // accumulate
        write_reg(2, 32'h0000_0000); // no shift
        write_reg(0, 32'h0003_0004); //  3 * 4 = 12
        expect_result(32'd12, "3 * 4");

        write_reg(0, 32'hFFFE_0005); // -2 * 5 = -10 ; acc = 2
        expect_result(32'd2, "12 + (-2)*5");

        write_reg(1, 32'h0000_0003); // accumulate + clear pulse
        if (result_reg_q !== 32'd0) $fatal(1, "Clear test failed");
        write_reg(2, 32'h0000_0001); // arithmetic shift by 1
        write_reg(0, 32'h0004_0003); // 12 >>> 1 = 6
        expect_result(32'd6, "shift positive");

        write_reg(0, 32'hFFFD_0003); // -9 >>> 1 = -5, acc = 1
        expect_result(32'd1, "shift negative");

        write_reg(1, 32'h0000_0000); // replace, don't accumulate
        write_reg(0, 32'h0007_0004); // 28 >>> 1 = 14
        expect_result(32'd14, "replace mode");

        write_reg(2, 32'h0000_0000);
        write_reg(0, 32'h8000_8000); // -32768 * -32768
        expect_result(32'h4000_0000, "signed edge case");

        write_reg(1, 32'h0000_0003); // clear + accumulate
        write_reg(0, 32'h8000_8000);
        expect_result(32'h4000_0000, "overflow step 1");
        write_reg(0, 32'h8000_8000);
        expect_result(32'h8000_0000, "overflow step 2");
        write_reg(0, 32'h8000_8000);
        expect_result(32'hC000_0000, "overflow step 3");
        write_reg(0, 32'h8000_8000);
        expect_result(32'h0000_0000, "overflow wraps to zero");

        $display("ALL TESTS PASSED");
        $finish;
    end
endmodule
