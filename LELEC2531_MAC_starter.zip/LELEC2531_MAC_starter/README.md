# LELEC2531 — MAC accelerator (proposed starter baseline)

This is an **independent proposal** for getting started with the project, not a provided lab solution. The actual Lab 5 system bus, address map, and processor interfaces need to be checked before integration.

## Project sources and important ambiguity
- `LELEC2531 - Project Description.pdf`: 32-bit input register, two 8-bit configuration registers, 32-bit output register. Integrate in the DE0-Nano processor, communicate through Raspberry Pi/SPI, compare baseline vs optimization.
- The topic PDF is named `P4 - AI Multiply-Accumulate Module` but its title on the page says **Project 6: Multiply-Accumulate Module**. Verify the topic number with teaching staff if it affects submissions.

## Proposed numerical specification (not imposed by the PDFs)
- Input word = `{A[15:0], B[15:0]}`, where A and B are signed 16-bit two's-complement numbers.
- `product = signed(A) * signed(B)` calculated with a 32-bit signed result.
- `scaled_product = product >>> CFG1[4:0]` (arithmetic right shift, 0 to 31).
- `result = CFG0[0] ? result + scaled_product : scaled_product`.
- Every arithmetic operation produces 32-bit wraparound results; saturation is not implemented.
- An input write automatically triggers an operation; the result is written at the **following** rising clock edge. The input word and execution configuration are captured in registers at the input write edge.
- Writing CFG0 with bit 1 set clears the accumulator. It is a write-one action, not a persistent mode. **Do not clear while an operation is still pending**; clear has priority and discards that pending update.

## Register interface of `mac_core` (abstract, not the final memory bus)

| Register | Width | Write strobe | Data | Read-back signal |
| --- | --- | --- | --- | --- |
| Input | 32 | `wr_input` | packed A/B | `input_reg_q` |
| Configuration 0 | 8 | `wr_cfg0` | bit0 accumulate, bit1 clear action | `cfg0_reg_q` (only bit0 retained) |
| Configuration 1 | 8 | `wr_cfg1` | bits4:0 product shift | `cfg1_reg_q` |
| Result | 32 | none | output of MAC | `result_reg_q` |

`result_valid` is asserted for one cycle following an output update. It can be useful for testing, though the project's minimum register specification does not require it.

## Suggested future memory map (illustrative ONLY)

- `BASE + 0x00`: INPUT, write (and optional readback)
- `BASE + 0x04`: CFG0, read/write
- `BASE + 0x08`: CFG1, read/write
- `BASE + 0x0C`: RESULT, read

The real `BASE`, bus strobes, chip select, register address decoding and read mux must follow the professor's Lab 5 files. You cannot connect this module directly to SPI or a DE0-Nano without the rest of the architecture.

## Simulating with ModelSim/Questa

Create a new project, add `rtl/mac_core.sv` and `tb/tb_mac_core.sv`, compile both, then run:

```tcl
vsim work.tb_mac_core
run -all
```

The testbench exercises signed multiplication, accumulation, clear, arithmetic right shifts, replace mode, extreme signed values, and 32-bit overflow. It should print `ALL TESTS PASSED` after successful execution.

Equivalent Icarus Verilog commands (if installed):

```sh
iverilog -g2012 -s tb_mac_core -o sim.vvp rtl/mac_core.sv tb/tb_mac_core.sv
vvp sim.vvp
```

**Simulation notice:** No HDL compiler was installed in the environment in which this starter pack was prepared, so compilation and simulation were not executed here. They must be validated on the student's machine.

## Next milestones
1. Create a MAC mathematical reference in Python with 32-bit wraparound, and compare it to waveforms from simulation.
2. Simulate back-to-back input writes, reset while active, configuration transitions and clear, as well as random operands.
3. Document datapath and control path in the intermediate report and synthesize this baseline in Quartus.
4. After Lab 5, connect it to the memory-mapped processor and validate with Raspberry Pi SPI + SignalTap.
5. For optimization, evaluate 8-bit dual MAC/SIMD, another pipeline architecture or saturation, and compare resources / timing / energy against the original design and software implementation.
